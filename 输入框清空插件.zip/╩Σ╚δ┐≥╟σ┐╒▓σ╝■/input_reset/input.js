;
// 方案一
// $(".input_item input").bind('input propertychange change', function() {
//     if ($(this).val() == "") {
//         $(this).parent().attr('data-attr', "");
//     } else {
//         $(this).parent().attr('data-attr', "\2716 ");
//     }
// })

// 伪类不能添加js事件
// $(".input_item input:after").click(function(e) {
//     alert(1)

// });


// 方案二
$(".input_item input").bind('input propertychange change', function() {
    if ($(this).val() == "") {
        $(this).parent().next().hide(300);
    } else {
        $(this).parent().next().show(300);
    }
});

$(".input_item .input_clear").click(function() {
    $(this).prev().children()[0].value = "";
    $(this).hide(300);
});

$(".input_item input").focus(function() {
    $(this).parent().prev().css({
        "background-color": "#cf2d28",
        "color": "#ffffff",
    });
})

$(".input_item input").blur(function() {
    $(this).parent().prev().css({ "background-color": "rgba(225, 225, 225, 0.6)", "color": "#cf2d28" });
})